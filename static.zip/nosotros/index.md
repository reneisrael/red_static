---
title: Directorio
id: 2
---
* * *

**Fundador**: Raful Rodríguez Pérez

**Presidente**: Deicy J. Cosme Tinoco

**Director General**: René Israel Valdez G.

**Gerente General**: Rafful Rodríguez Sánchez

**Director Editorial**: Carolina Bastida Rodríguez

**Gerente Comercial**: Ma. Isolda Sánchez Gómez

**Jefe de Información y Redacción**: Marco Antonio Morales
Mora

**Relaciones Públicas**: Armando Torres Estrada

* * *